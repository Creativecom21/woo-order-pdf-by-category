<?php
/*
Plugin Name: WooCommerce Order PDF by Category
Description: Génère un PDF des produits de plusieurs commandes, classés par catégorie principale.
Version: 1.0
Author: Creativecom-Bourgogne
*/

if (!defined('ABSPATH')) exit; // Sortie si accès direct

define('WOOOPBC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WOOOPBC_PLUGIN_URL', plugin_dir_url(__FILE__));

add_action('admin_menu', 'wooopbc_add_admin_menu');
add_action('admin_enqueue_scripts', 'wooopbc_enqueue_custom_styles');
add_action('admin_init', 'wooopbc_process_form');

function wooopbc_check_woocommerce() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'wooopbc_woocommerce_missing_notice');
        return false;
    }
    return true;
}

function wooopbc_woocommerce_missing_notice() {
    echo '<div class="error"><p>' . esc_html__('Le plugin WooCommerce Order PDF by Category nécessite WooCommerce pour fonctionner.', 'woo-order-pdf-by-category') . '</p></div>';
}

function wooopbc_add_admin_menu() {
    add_menu_page(
        'Commandes PDF par Catégorie',
        'Commandes PDF',
        'manage_woocommerce',
        'woo-order-pdf-by-category',
        'wooopbc_admin_page'
    );
}

function wooopbc_enqueue_custom_styles() {
    wp_enqueue_style('wooopbc-custom-styles', WOOOPBC_PLUGIN_URL . 'wooopbc-styles.css');
}

function wooopbc_admin_page() {
    if (!current_user_can('manage_woocommerce')) {
        wp_die(esc_html__('Vous n\'avez pas les permissions suffisantes pour accéder à cette page.', 'woo-order-pdf-by-category'));
    }

    if (!wooopbc_check_woocommerce()) {
        return;
    }

    $order_statuses = wc_get_order_statuses();
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Générer PDF des commandes par catégorie', 'woo-order-pdf-by-category'); ?></h1>
        <form method="post" action="">
            <?php wp_nonce_field('wooopbc_filter_orders', 'wooopbc_filter_nonce'); ?>
            <div style="display: flex; align-items: center; margin-bottom: 20px;">
                <div style="margin-right: 20px;">
                    <label for="start_date"><?php echo esc_html__('Date de début :', 'woo-order-pdf-by-category'); ?></label>
                    <input type="date" id="start_date" name="start_date" required>
                </div>
                <div>
                    <label for="end_date"><?php echo esc_html__('Date de fin :', 'woo-order-pdf-by-category'); ?></label>
                    <input type="date" id="end_date" name="end_date" required>
                </div>
            </div>
            <div style="margin-bottom: 20px;">
                <label><?php echo esc_html__('Statuts de commande :', 'woo-order-pdf-by-category'); ?></label>
                <div style="display: flex; flex-wrap: wrap;">
                    <?php foreach ($order_statuses as $status => $label) : ?>
                        <div style="margin-right: 15px;">
                            <label>
                                <input type="checkbox" name="order_statuses[]" value="<?php echo esc_attr($status); ?>">
                                <?php echo esc_html($label); ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <input type="submit" name="filter_orders" value="<?php echo esc_attr__('Filtrer Commandes', 'woo-order-pdf-by-category'); ?>" class="button button-primary wooopbc-button">
        </form>
        <?php
        if (isset($_POST['filter_orders']) && check_admin_referer('wooopbc_filter_orders', 'wooopbc_filter_nonce')) {
            $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
            $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';
            $selected_statuses = isset($_POST['order_statuses']) ? array_map('sanitize_text_field', $_POST['order_statuses']) : array();
            
            $args = array(
                'limit' => -1,
                'date_created' => $start_date . '...' . $end_date,
            );
            
            if (!empty($selected_statuses)) {
                $args['status'] = $selected_statuses;
            }
            
            $orders = wc_get_orders($args);
            
            echo '<form method="post" action="" id="generate-pdf-form">';
            wp_nonce_field('wooopbc_generate_pdf', 'wooopbc_nonce');
            echo '<div style="margin-bottom: 10px;">';
            echo '<button type="button" id="select-all-orders" class="button wooopbc-button">' . esc_html__('Sélectionner toutes les commandes', 'woo-order-pdf-by-category') . '</button>';
            echo '</div>';
            foreach ($orders as $order) {
                echo '<label><input type="checkbox" name="order_ids[]" value="' . esc_attr($order->get_id()) . '"> ' . 
                     esc_html__('Commande #', 'woo-order-pdf-by-category') . esc_html($order->get_id()) . ' - ' . 
                     esc_html($order->get_date_created()->date('Y-m-d')) . ' - ' . 
                     esc_html(wc_get_order_status_name($order->get_status())) . '</label><br>';
            }
            echo '<input type="hidden" name="start_date" value="' . esc_attr($start_date) . '">';
            echo '<input type="hidden" name="end_date" value="' . esc_attr($end_date) . '">';
            foreach ($selected_statuses as $status) {
                echo '<input type="hidden" name="order_statuses[]" value="' . esc_attr($status) . '">';
            }
            echo '<input type="submit" name="generate_pdf" value="' . esc_attr__('Générer PDF', 'woo-order-pdf-by-category') . '" class="button button-primary wooopbc-button">';
            echo '</form>';
            
            ?>
            <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {
                var selectAllButton = document.getElementById('select-all-orders');
                var form = document.getElementById('generate-pdf-form');
                var checkboxes = form.querySelectorAll('input[type="checkbox"][name="order_ids[]"]');
                
                selectAllButton.addEventListener('click', function() {
                    checkboxes.forEach(function(checkbox) {
                        checkbox.checked = true;
                    });
                });
            });
            </script>
            <?php
        }
        ?>
    </div>
    <?php
}

function wooopbc_process_form() {
    if (isset($_POST['generate_pdf']) && !empty($_POST['order_ids'])) {
        if (!isset($_POST['wooopbc_nonce']) || !wp_verify_nonce($_POST['wooopbc_nonce'], 'wooopbc_generate_pdf')) {
            wp_die(esc_html__('Erreur de sécurité. Veuillez réessayer.', 'woo-order-pdf-by-category'));
        }
        $order_ids = array_map('intval', $_POST['order_ids']);
        wooopbc_generate_pdf($order_ids);
    }
}

function wooopbc_generate_pdf($order_ids) {
    if (!current_user_can('manage_woocommerce')) {
        wp_die(esc_html__('Vous n\'avez pas les permissions suffisantes pour générer ce PDF.', 'woo-order-pdf-by-category'));
    }

    require_once(WOOOPBC_PLUGIN_DIR . 'tcpdf/tcpdf.php');

    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetTitle(esc_html__('Commandes par Catégorie', 'woo-order-pdf-by-category'));
    $pdf->SetHeaderData('', 0, esc_html__('Commandes par Catégorie', 'woo-order-pdf-by-category'), '');
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
    $pdf->SetFont('dejavusans', '', 10);
    $pdf->AddPage();

    $products_by_category = array();

    foreach ($order_ids as $order_id) {
        $order = wc_get_order($order_id);
        if ($order) {
            foreach ($order->get_items() as $item) {
                $product = $item->get_product();
                if ($product) {
                    $categories = wooopbc_get_top_level_category($product);
                    foreach ($categories as $category) {
                        if (!isset($products_by_category[$category])) {
                            $products_by_category[$category] = array();
                        }
                        if (!isset($products_by_category[$category][$product->get_id()])) {
                            $products_by_category[$category][$product->get_id()] = array(
                                'name' => $product->get_name(),
                                'quantity' => 0
                            );
                        }
                        $products_by_category[$category][$product->get_id()]['quantity'] += $item->get_quantity();
                    }
                }
            }
        }
    }

    ksort($products_by_category);

    foreach ($products_by_category as $category => $products) {
        $pdf->SetFont('', 'B', 14);
        $pdf->Cell(0, 10, $category, 0, 1);
        $pdf->SetFont('', '', 10);

        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(100, 7, esc_html__('Nom du produit', 'woo-order-pdf-by-category'), 1, 0, 'L', 1);
        $pdf->Cell(30, 7, esc_html__('Quantité', 'woo-order-pdf-by-category'), 1, 1, 'C', 1);

        $fill = false;
        foreach ($products as $product) {
            $pdf->Cell(100, 6, $product['name'], 1, 0, 'L', $fill);
            $pdf->Cell(30, 6, $product['quantity'], 1, 1, 'C', $fill);
            $fill = !$fill;
        }

        $pdf->Ln(10);
    }

    $pdf->Output('commandes_par_categorie.pdf', 'D');
    exit;
}

function wooopbc_get_top_level_category($product) {
    if ($product->is_type('variation')) {
        $product = wc_get_product($product->get_parent_id());
    }

    $terms = get_the_terms($product->get_id(), 'product_cat');
    if (!$terms || is_wp_error($terms)) {
        return array(esc_html__('Sans catégorie', 'woo-order-pdf-by-category'));
    }
    
    $top_level_categories = array();
    foreach ($terms as $term) {
        $ancestors = get_ancestors($term->term_id, 'product_cat', 'taxonomy');
        if (empty($ancestors)) {
            $top_level_categories[] = $term->name;
        } else {
            $top_most_ancestor_id = end($ancestors);
            $top_most_ancestor = get_term($top_most_ancestor_id, 'product_cat');
            if ($top_most_ancestor && !is_wp_error($top_most_ancestor)) {
                $top_level_categories[] = $top_most_ancestor->name;
            }
        }
    }
    
    $top_level_categories = array_unique($top_level_categories);
    
    return !empty($top_level_categories) ? $top_level_categories : array(esc_html__('Sans catégorie', 'woo-order-pdf-by-category'));
}
